
<?php 
session_start();
// var_dump($_SESSION); die();
if (!isset($_SESSION['user']['isLoggedIn'])) {
  header("Location: login.php");
  # code...
}
$myMsg = null;

if (isset($_SESSION['mymsg']))
{
  // var_dump($_SESSION['mymsg']);die();
  $myMsg = $_SESSION['mymsg'];

  unset ($_SESSION['mymsg']);
}

include "header.php";
?>


    <header>
      <!-- Fixed navbar -->
      <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
        <a class="navbar-brand" href="#">Content Creator</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
              <a class="nav-link" href="#">Current login: <?php echo $_SESSION['user']['name'] ?></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="functions/actionLogout.php">Logout</a>
            </li>
          </ul>
          <form class="form-inline mt-2 mt-md-0">
            <input class="form-control mr-sm-2" type="text" placeholder="Search" aria-label="Search">
            <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
          </form>
        </div>
      </nav>
    </header>

    <!-- Begin page content -->
<form action="functions/actionCreatePost.php" method="post">
    <main role="main" class="container">
      <br>
      <h1 class="mt-5">Input content</h1><br>
    

      <div class="form-group">
        <label for="formGroupExampleInput">Title</label>
        <input type="text" class="form-control" id="formGroupExampleInput" placeholder="Example title" name="title">
      </div>
      <div class="form-group">
        <label for="exampleFormControlTextarea1">Short Description</label>
        <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" name="shortDescription"></textarea>
      </div>
      <div class="form-group">
        <label for="exampleFormControlTextarea1">Long Description</label>
        <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" name="longDescription"></textarea>
        <br>
        <input type="submit" name=""><br>
        <br><h3><?= $myMsg ?> 
            </h3>


      </div>
      
    </main>

</form>
<?php 

include "footer.php"

 ?>