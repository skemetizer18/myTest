<?php
session_start();

 if (isset($_POST)) {
   // var_dump($_POST);die();


  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "test";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);

}

if ($_POST['title'] == '' || $_POST['shortDescription'] == '' || $_POST['longDescription'] == '') {
	
	$_SESSION['mymsg'] = "Please enter all required fields.";
	header("Location: ../index.php");
	exit();
}
// var_dump($_POST);die();


$title = mysqli_escape_string($conn,$_POST['title']);
$shortDesc = mysqli_escape_string($conn,$_POST['shortDescription']);
$longDesc = mysqli_escape_string($conn,$_POST['longDescription']);
$userID = mysqli_escape_string($conn,$_SESSION['user']['id'] );


$sql = "INSERT INTO post (userID, title, shortDesc, longDesc) VALUES ('$userID','$title','$shortDesc','$longDesc')";

// var_dump($sql);die();

if ($conn->query($sql)) {


	$_SESSION['mymsg'] = "Post successfully created";

}
header("Location: ../index.php");
// var_dump($sql);die();
echo "Something Wrong";

// var_dump($conn);die();

}
?>