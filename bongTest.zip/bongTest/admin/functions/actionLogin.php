
<?php 

 if (isset($_POST)) {
   // var_dump($_POST);die();

  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "test";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
  // echo $_POST['password'];die();
$email = mysqli_escape_string($conn,$_POST['email']);
$pass = mysqli_escape_string($conn, md5($_POST['password']) );

$sql = "SELECT * FROM user where email = '$email' and password='$pass' ";

$result = $conn->query($sql);

if ($result->num_rows > 0) {

	session_start();

	$data = $result->fetch_assoc();

	// var_dump($data['name']);die();

	$_SESSION['user']['isLoggedIn'] = true;
	$_SESSION['user']['id'] = $data['id'];
	$_SESSION['user']['name'] = $data['name'];
	// var_dump($data);die;
	
	header("Location: ../index.php");
	 var_dump($result->fetch_assoc());die;
	// $data = $result->fetch_assoc();
	// var_dump($data['name']);
	// die();

}

echo "WRONG EMAIL/PASSWORD";die;

}

?>



