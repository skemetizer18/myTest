
<script type="text/javascript" src="../js/bootstrap.min.js"></script>
<script type="text/javascript" src="../js/jquery.js"></script>
<script type="text/javascript">
	(function ( $ ) { 

    // put all that "wl_alert" code here   

}( jQuery ));</script>
