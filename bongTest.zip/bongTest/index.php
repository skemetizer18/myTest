<?php
session_start();

 if (isset($_POST)) {
   // var_dump($_POST);die();


  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "test";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);

}


	$sql = "SELECT  post.id,user.name, post.title, post.shortDesc, post.longDesc 
	FROM post INNER JOIN user ON user.id = post.userID ORDER BY post.id ASC";
	$result = $conn->query($sql);

	$data = [];

	while($row = $result->fetch_assoc()) {
	    $data[] = $row;
	}
}
?>

<!DOCTYPE html>
<!--
	Awesome Responsive Template
	templatestock.co
-->
<html>
<head>
	<title>Bong Test</title>
	<!-- Bootstrap CSS -->
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">

	<!-- Goggle Font -->
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">

	<!-- Font Css -->
	<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">

	<!-- Custom CSS -->
	<link rel="stylesheet" type="text/css" href="css/style.css">

	<!-- Animation Css -->
	<link rel="stylesheet" href="css/animate.css">


</head>
<body>


<div class="container" id="Services">
	<div class="row">
		<div class="col-md-12">
			<div class="main_heading">
				<h1>POSTS</h1>
				<div  class="text-center"><span class="underline"></span></div>
			</div>
		</div><!-- End col-md-12 -->
	</div><!-- End row -->

	<?php foreach ($data as $key => $value) { ?>
	<div class="col-md-6 services-box-gray col-sm-6 mb-2">
		<div class="services-box">
			<i class="fa fa-support"></i>
			<h4><?= substr($value['title'], 0, 50) ?></h4>
			<p><?= substr($value['title'], 0, 100) ?></p>
			<p style="font-style: italic;">Author: <?= $value['name'] ?></p>
			<a href="post.php?id=<?= $value['id'] ?>">Read More..</a>
		</div>
	</div><!-- End col-md-4-->
	<?php } ?>


</div><!-- End container -->

<!-- End Services -->




	

<!-- End Footer -->


<script type="text/javascript" src="js/jquery-main.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script src="js/wow.min.js"></script>

<script>
	new WOW().init();
</script>



</body>
</html>