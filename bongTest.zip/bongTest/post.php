<?php

$id = null;


if (isset($_GET['id'])) {


  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "test";

	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);

	
	$id = mysqli_escape_string($conn, $_GET['id']);

	$sql = "select u.name, p.title, p.shortDesc, p.longDesc from post p INNER JOIN user u on u.id = p.userID WHERE p.id = '$id'";

	$result = $conn->query($sql);

	$data = $result->fetch_assoc();

}else{
	header('index.php');
}

?>

<!DOCTYPE html>

<html>
<head>
	<title>Awesome Responsive Template | Template Stock</title>
	<!-- Bootstrap CSS -->
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<!-- Goggle Font -->
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">
	<!-- Font Css -->
	<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
	<!-- Custom CSS -->
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<!-- Animation Css -->
	<link rel="stylesheet" href="css/animate.css">


</head>
<body>

<!-- Call to Action -->
<div class="call-action-bg" id="Call-to-Action">
	<a href="index.php">Go back</a>
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="main_heading">
					<h1><?= $data['title'] ?></h1>
					<p>Author: <?= $data['name'] ?></p>
					<div  class="text-center"><span class="underline"></span></div>
				</div>
			</div><!-- End col-md-12 -->
		</div><!-- End row -->

		<div class="col-md-12">
			
			<h4><?= $data['shortDesc'] ?></h4>
			<p><?= $data['longDesc'] ?></p>
		</div><!-- End col-md-12-->

	</div><!-- End container -->	
</div>

<!-- End Call to Action -->







<!-- Footer -->


<script type="text/javascript" src="js/jquery-main.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script src="js/wow.min.js"></script>

<script>
	new WOW().init();
</script>

</body>
</html>